# Mappa delle funzioni

## Funzioni trasversali
- login e recupero password;
- ruoli owner, admin, member e viewer;
- dashboard con KPI calcolati dai dati;
- ricerca, filtri e ordinamento;
- importazione ed esportazione CSV;
- backup e ripristino JSON;
- stampa di preventivi, ordini e fatture;
- caricamento documenti su Storage privato;
- controllo sovrapposizioni per prenotazioni, appuntamenti e turni;
- audit log delle modifiche;
- PWA e utilizzo responsive.

## Sezioni generate
| Sezione | Campi | Viste | Operazioni |
|---|---:|---|---|
| Clienti | 5 | Tabella, Schede | CRUD, ricerca, CSV |
| Attività | 6 | Tabella, Bacheca, Agenda | CRUD, ricerca, CSV |
| Preventivi | 7 | Tabella, Bacheca, Agenda | CRUD, ricerca, CSV |
| Righe preventivo | 5 | Tabella | CRUD, ricerca, CSV |
| Pagamenti | 6 | Tabella, Bacheca, Agenda | CRUD, ricerca, CSV |
| Registro automazioni | 4 | Tabella, Bacheca | CRUD, ricerca, CSV |
| Attività AI | 4 | Tabella, Bacheca | CRUD, ricerca, CSV |

## Integrazioni esterne
Le automazioni email, webhook, AI e pagamenti diventano operative soltanto dopo aver configurato le credenziali indicate in ".env.example" e aver eseguito i relativi test.
