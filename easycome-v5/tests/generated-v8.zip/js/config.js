window.APP_CONFIG = {
  "supabaseUrl": "https://example.supabase.co",
  "supabaseAnonKey": "anon-test",
  "dataMode": "local",
  "easycomeBaseUrl": "https://easy-come.it",
  "project": {
    "version": "8.0.0",
    "generatedAt": "2026-08-07T11:23:46.434Z",
    "organizationId": "952d086d-613d-4099-8af8-62ea40e736fc",
    "company": {
      "name": "Impresa Test 51",
      "slug": "impresa-test-51",
      "industry": "Impresa e servizi",
      "description": "Clienti, attività, preventivi, pagamenti, report, automazioni, app e manuale. Flusso completo e verificabile.",
      "email": "titolare51@example.com",
      "phone": "",
      "primaryColor": "#275dff",
      "accentColor": "#17213b",
      "surfaceColor": "#f7f8fb",
      "currency": "EUR",
      "locale": "it-IT",
      "logoData": "",
      "style": "studio",
      "layout": "studio"
    },
    "modules": [
      "crm",
      "tasks",
      "quotes",
      "payments",
      "reports",
      "automations",
      "multiuser",
      "website",
      "mobile_app",
      "branding",
      "ai",
      "easycome_hub"
    ],
    "customEntities": [],
    "automations": [],
    "hub": {
      "enabled": true,
      "manual": true,
      "support": true,
      "featureRequests": true,
      "onboarding": true,
      "updates": true
    },
    "pricing": {
      "mode": "none",
      "enabled": false,
      "basePrice": 60,
      "unit": "servizio",
      "taxPerPerson": 0,
      "depositPercent": 0,
      "minimumUnits": 1,
      "renewalNoticeDays": 15,
      "rules": [],
      "extras": []
    },
    "identity": {
      "provider": "easycome",
      "supabaseUrl": "https://example.supabase.co",
      "supabaseAnonKey": "anon-test",
      "ownerUserId": "00000000-0000-4000-8000-000000000001",
      "ownerEmail": "titolare51@example.com",
      "easycomeBaseUrl": "https://easy-come.it",
      "dataMode": "local"
    },
    "delivery": {
      "packagePrice": 99,
      "implementationPrice": 150,
      "implementationSelected": false,
      "managedServiceSelected": true,
      "managedServicePrice": 30,
      "notes": "",
      "supportDays": 30,
      "previewApproved": true
    },
    "entities": [
      {
        "key": "customers",
        "label": "Clienti",
        "singular": "Cliente",
        "icon": "users",
        "fields": [
          {
            "key": "name",
            "label": "Nome / Ragione sociale",
            "type": "text",
            "required": true
          },
          {
            "key": "email",
            "label": "Email",
            "type": "email"
          },
          {
            "key": "phone",
            "label": "Telefono",
            "type": "phone"
          },
          {
            "key": "tax_code",
            "label": "Codice fiscale / P. IVA",
            "type": "text"
          },
          {
            "key": "notes",
            "label": "Note",
            "type": "longtext"
          }
        ]
      },
      {
        "key": "tasks",
        "label": "Attività",
        "singular": "Attività",
        "icon": "check-square",
        "fields": [
          {
            "key": "title",
            "label": "Titolo",
            "type": "text",
            "required": true
          },
          {
            "key": "status",
            "label": "Stato",
            "type": "select",
            "options": [
              "Da fare",
              "In corso",
              "Completata"
            ]
          },
          {
            "key": "priority",
            "label": "Priorità",
            "type": "select",
            "options": [
              "Bassa",
              "Media",
              "Alta",
              "Urgente"
            ]
          },
          {
            "key": "due_date",
            "label": "Scadenza",
            "type": "date"
          },
          {
            "key": "assignee",
            "label": "Responsabile",
            "type": "text"
          },
          {
            "key": "notes",
            "label": "Note",
            "type": "longtext"
          }
        ]
      },
      {
        "key": "quotes",
        "label": "Preventivi",
        "singular": "Preventivo",
        "icon": "file-text",
        "fields": [
          {
            "key": "number",
            "label": "Numero",
            "type": "text",
            "required": true
          },
          {
            "key": "customer_name",
            "label": "Cliente",
            "type": "text",
            "required": true
          },
          {
            "key": "issue_date",
            "label": "Data",
            "type": "date"
          },
          {
            "key": "valid_until",
            "label": "Valido fino al",
            "type": "date"
          },
          {
            "key": "status",
            "label": "Stato",
            "type": "select",
            "options": [
              "Bozza",
              "Inviato",
              "Accettato",
              "Rifiutato"
            ]
          },
          {
            "key": "total",
            "label": "Totale",
            "type": "currency"
          },
          {
            "key": "notes",
            "label": "Note",
            "type": "longtext"
          }
        ]
      },
      {
        "key": "quote_items",
        "label": "Righe preventivo",
        "singular": "Riga preventivo",
        "icon": "list",
        "system": true,
        "fields": [
          {
            "key": "quote_number",
            "label": "Numero preventivo",
            "type": "text",
            "required": true
          },
          {
            "key": "description",
            "label": "Descrizione",
            "type": "text",
            "required": true
          },
          {
            "key": "quantity",
            "label": "Quantità",
            "type": "number",
            "required": true
          },
          {
            "key": "unit_price",
            "label": "Prezzo unitario",
            "type": "currency",
            "required": true
          },
          {
            "key": "total",
            "label": "Totale riga",
            "type": "currency"
          }
        ]
      },
      {
        "key": "payments",
        "label": "Pagamenti",
        "singular": "Pagamento",
        "icon": "credit-card",
        "fields": [
          {
            "key": "customer_name",
            "label": "Cliente",
            "type": "text"
          },
          {
            "key": "payment_date",
            "label": "Data",
            "type": "date"
          },
          {
            "key": "amount",
            "label": "Importo",
            "type": "currency",
            "required": true
          },
          {
            "key": "method",
            "label": "Metodo",
            "type": "select",
            "options": [
              "Contanti",
              "Carta",
              "Bonifico",
              "Online",
              "Altro"
            ]
          },
          {
            "key": "status",
            "label": "Stato",
            "type": "select",
            "options": [
              "Previsto",
              "Ricevuto",
              "Rimborsato"
            ]
          },
          {
            "key": "reference",
            "label": "Riferimento",
            "type": "text"
          }
        ]
      },
      {
        "key": "automation_log",
        "label": "Registro automazioni",
        "singular": "Esecuzione",
        "icon": "zap",
        "system": true,
        "fields": [
          {
            "key": "workflow_name",
            "label": "Automazione",
            "type": "text"
          },
          {
            "key": "event_name",
            "label": "Evento",
            "type": "text"
          },
          {
            "key": "status",
            "label": "Esito",
            "type": "select",
            "options": [
              "In attesa",
              "Eseguita",
              "Errore"
            ]
          },
          {
            "key": "details",
            "label": "Dettagli",
            "type": "longtext"
          }
        ]
      },
      {
        "key": "ai_requests",
        "label": "Attività AI",
        "singular": "Attività AI",
        "icon": "sparkles",
        "system": true,
        "fields": [
          {
            "key": "request_type",
            "label": "Tipo",
            "type": "text"
          },
          {
            "key": "input_text",
            "label": "Input",
            "type": "longtext"
          },
          {
            "key": "output_text",
            "label": "Output",
            "type": "longtext"
          },
          {
            "key": "status",
            "label": "Stato",
            "type": "select",
            "options": [
              "Richiesta",
              "Completata",
              "Errore"
            ]
          }
        ]
      }
    ],
    "price": {
      "base": 99,
      "implementation": 0,
      "implementationSelected": false,
      "modules": 81,
      "customEntities": 0,
      "customFields": 0,
      "automations": 0,
      "pricingRules": 0,
      "bundleDiscount": 16.2,
      "extras": 64.8,
      "total": 163.8
    }
  }
};
