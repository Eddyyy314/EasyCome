# App PWA

La cartella mobile contiene una web app installabile. Non sono inclusi file binari App Store o Play Store. Per creare pacchetti nativi usa Capacitor e account sviluppatore intestati al cliente.
