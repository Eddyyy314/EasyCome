# Specifica funzionale — Impresa Test 51

## Obiettivo
Clienti, attività, preventivi, pagamenti, report, automazioni, app e manuale. Flusso completo e verificabile.

## Moduli attivi
- Clienti e CRM\n- Attività e scadenze\n- Preventivi\n- Registro pagamenti e caparre\n- Report e KPI\n- Motore automazioni\n- Utenti, ruoli e permessi\n- Sito pubblico coordinato\n- App PWA installabile\n- Brand kit completo\n- AI tramite integrazione\n- Manuale & Easy Come Hub

## Sezioni dati
### Clienti
- Nome / Ragione sociale (text) — obbligatorio\n- Email (email)\n- Telefono (phone)\n- Codice fiscale / P. IVA (text)\n- Note (longtext)\n\n### Attività
- Titolo (text) — obbligatorio\n- Stato (select)\n- Priorità (select)\n- Scadenza (date)\n- Responsabile (text)\n- Note (longtext)\n\n### Preventivi
- Numero (text) — obbligatorio\n- Cliente (text) — obbligatorio\n- Data (date)\n- Valido fino al (date)\n- Stato (select)\n- Totale (currency)\n- Note (longtext)\n\n### Righe preventivo
- Numero preventivo (text) — obbligatorio\n- Descrizione (text) — obbligatorio\n- Quantità (number) — obbligatorio\n- Prezzo unitario (currency) — obbligatorio\n- Totale riga (currency)\n\n### Pagamenti
- Cliente (text)\n- Data (date)\n- Importo (currency) — obbligatorio\n- Metodo (select)\n- Stato (select)\n- Riferimento (text)\n\n### Registro automazioni
- Automazione (text)\n- Evento (text)\n- Esito (select)\n- Dettagli (longtext)\n\n### Attività AI
- Tipo (text)\n- Input (longtext)\n- Output (longtext)\n- Stato (select)

## Automazioni
- Nessuna automazione personalizzata
