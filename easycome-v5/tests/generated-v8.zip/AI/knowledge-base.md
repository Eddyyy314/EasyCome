# Knowledge base — Impresa Test 51

## Attività
Clienti, attività, preventivi, pagamenti, report, automazioni, app e manuale. Flusso completo e verificabile.

## Regole
- Non inventare prezzi o disponibilità.
- Chiedere conferma quando mancano dati.
- Non condividere informazioni riservate.
