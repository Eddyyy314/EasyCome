# Assistente AI — Impresa Test 51

Il pacchetto include una funzione server compatibile con provider API configurabili.

Variabili richieste:

- `AI_API_URL`
- `AI_API_KEY`
- `AI_MODEL`

L’assistente non è attivo finché non vengono inserite credenziali valide e definite le regole privacy dell’impresa. Non inviare dati sensibili senza una base giuridica e una configurazione adeguata.
