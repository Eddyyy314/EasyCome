-- Easy Come Studio V8 — schema Supabase
-- Progetto: Impresa Test 51
-- Generato: 2026-08-08T12:32:04.519Z
-- Eseguibile più volte: policy, trigger e seed sono idempotenti.

create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create table if not exists public.organizations (
  id uuid primary key,
  name text not null,
  slug text not null unique,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member','viewer')),
  email text,
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);

alter table public.organization_members add column if not exists email text;

create table if not exists public.app_settings (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  key text not null,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (organization_id, key)
);

create table if not exists public.automation_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  entity text not null,
  event_type text not null,
  record_id uuid,
  payload jsonb not null default '{}'::jsonb,
  status text not null default 'pending' check (status in ('pending','processing','done','error')),
  error_message text,
  dedupe_key text unique,
  created_at timestamptz not null default now(),
  processed_at timestamptz
);

create table if not exists public.automation_log (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  workflow_name text,
  event_name text,
  status text not null default 'In attesa',
  details text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.internal_notifications (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  title text not null,
  message text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  table_name text not null,
  record_id uuid,
  action text not null check (action in ('INSERT','UPDATE','DELETE')),
  actor_id uuid references auth.users(id) on delete set null,
  old_data jsonb,
  new_data jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.public_submission_limits (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  client_token text not null,
  submitted_at timestamptz not null default now()
);

create table if not exists public.public_submissions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  source text not null default 'request',
  name text,
  email text,
  phone text,
  message text,
  status text not null default 'Nuova',
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.org_role(p_organization_id uuid)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.organization_members
  where organization_id = p_organization_id and user_id = auth.uid()
  limit 1;
$$;

create or replace function public.org_can_read(p_organization_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select public.org_role(p_organization_id) in ('owner','admin','member','viewer'); $$;

create or replace function public.org_can_write(p_organization_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select public.org_role(p_organization_id) in ('owner','admin','member'); $$;

create or replace function public.org_can_admin(p_organization_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select public.org_role(p_organization_id) in ('owner','admin'); $$;

create or replace function public.get_my_role(p_organization_id uuid)
returns text language sql stable security definer set search_path = public
as $$ select public.org_role(p_organization_id); $$;
grant execute on function public.get_my_role(uuid) to authenticated;

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function public.claim_owner_by_email(p_organization_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  expected_email text;
  current_email text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select lower(nullif(settings->'brand'->>'email','')) into expected_email
  from public.organizations where id = p_organization_id;
  current_email := lower(coalesce(auth.jwt()->>'email',''));
  if expected_email is null then raise exception 'Owner email not configured'; end if;
  if current_email <> expected_email then raise exception 'Email not authorized as owner'; end if;
  if exists (select 1 from public.organization_members where organization_id = p_organization_id) then return false; end if;
  insert into public.organization_members (organization_id, user_id, role, email)
  values (p_organization_id, auth.uid(), 'owner', current_email)
  on conflict do nothing;
  return true;
end;
$$;

grant execute on function public.claim_owner_by_email(uuid) to authenticated;

create or replace function public.submit_public_request(
  p_organization_id uuid,
  p_source text,
  p_payload jsonb,
  p_client_token text,
  p_website text default ''
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  new_id uuid;
  recent_count integer;
begin
  if coalesce(trim(p_website),'') <> '' then raise exception 'Invalid request'; end if;
  if not exists (select 1 from public.organizations where id = p_organization_id) then raise exception 'Organization not found'; end if;
  if length(coalesce(p_client_token,'')) < 8 then raise exception 'Invalid client token'; end if;
  if octet_length(p_payload::text) > 25000 then raise exception 'Request too large'; end if;
  select count(*) into recent_count from public.public_submission_limits
  where organization_id = p_organization_id and client_token = p_client_token
    and submitted_at > now() - interval '10 minutes';
  if recent_count >= 5 then raise exception 'Troppe richieste. Riprova tra qualche minuto.'; end if;
  insert into public.public_submission_limits (organization_id, client_token) values (p_organization_id, p_client_token);
  delete from public.public_submission_limits where submitted_at < now() - interval '24 hours';
  insert into public.public_submissions (
    organization_id, source, name, email, phone, message, payload
  ) values (
    p_organization_id,
    coalesce(nullif(p_source, ''), 'request'),
    nullif(p_payload->>'name', ''),
    nullif(p_payload->>'email', ''),
    nullif(p_payload->>'phone', ''),
    nullif(p_payload->>'message', ''),
    p_payload
  ) returning id into new_id;
  return new_id;
end;
$$;

grant execute on function public.submit_public_request(uuid, text, jsonb, text, text) to anon, authenticated;

create or replace function public.queue_automation_event()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.automation_events (organization_id, entity, event_type, record_id, payload)
  values (
    new.organization_id,
    tg_table_name,
    case
      when tg_table_name = 'public_submissions' and tg_op = 'INSERT' then 'public_request'
      when tg_op = 'INSERT' then 'record_created'
      else 'record_updated'
    end,
    new.id,
    to_jsonb(new)
  );
  if tg_op = 'UPDATE' and (to_jsonb(old)->>'status') is distinct from (to_jsonb(new)->>'status') then
    insert into public.automation_events (organization_id, entity, event_type, record_id, payload)
    values (new.organization_id, tg_table_name, 'status_changed', new.id, to_jsonb(new));
  end if;
  return new;
end;
$$;

create or replace function public.audit_record_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  org uuid;
  rid uuid;
begin
  org := coalesce(new.organization_id, old.organization_id);
  rid := coalesce(new.id, old.id);
  insert into public.audit_log (organization_id, table_name, record_id, action, actor_id, old_data, new_data)
  values (org, tg_table_name, rid, tg_op, auth.uid(), case when tg_op <> 'INSERT' then to_jsonb(old) end, case when tg_op <> 'DELETE' then to_jsonb(new) end);
  return coalesce(new, old);
end;
$$;

insert into public.organizations (id, name, slug, settings)
values (
  '701435c5-2b49-4228-b664-978568acc095',
  'Impresa Test 51',
  'impresa-test-51',
  '{"brand":{"name":"Impresa Test 51","slug":"impresa-test-51","industry":"Impresa e servizi","description":"Clienti, attività, preventivi, pagamenti, report, automazioni, app e manuale. Flusso completo e verificabile.","email":"titolare51@example.com","phone":"","primaryColor":"#275dff","accentColor":"#17213b","surfaceColor":"#f7f8fb","currency":"EUR","locale":"it-IT","logoData":"","style":"studio","layout":"studio"},"modules":["crm","tasks","quotes","payments","reports","automations","multiuser","website","mobile_app","branding","ai","easycome_hub"],"version":"8.3.0"}'::jsonb
)
on conflict (id) do update set name = excluded.name, slug = excluded.slug, settings = excluded.settings;

alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.app_settings enable row level security;
alter table public.automation_events enable row level security;
alter table public.automation_log enable row level security;
alter table public.internal_notifications enable row level security;
alter table public.audit_log enable row level security;
alter table public.public_submission_limits enable row level security;
alter table public.public_submissions enable row level security;

drop policy if exists "organizations_member_select" on public.organizations;
create policy "organizations_member_select" on public.organizations for select using (public.org_can_read(id));

drop policy if exists "members_member_select" on public.organization_members;
drop policy if exists "members_admin_insert" on public.organization_members;
drop policy if exists "members_admin_update" on public.organization_members;
drop policy if exists "members_admin_delete" on public.organization_members;
create policy "members_member_select" on public.organization_members for select using (user_id = auth.uid() or public.org_can_read(organization_id));
create policy "members_admin_insert" on public.organization_members for insert with check (public.org_can_admin(organization_id));
create policy "members_admin_update" on public.organization_members for update using (public.org_can_admin(organization_id)) with check (public.org_can_admin(organization_id));
create policy "members_admin_delete" on public.organization_members for delete using (public.org_can_admin(organization_id));

drop policy if exists "settings_member_select" on public.app_settings;
drop policy if exists "settings_admin_write" on public.app_settings;
create policy "settings_member_select" on public.app_settings for select using (public.org_can_read(organization_id));
create policy "settings_admin_write" on public.app_settings for all using (public.org_can_admin(organization_id)) with check (public.org_can_admin(organization_id));

drop policy if exists "automation_admin_select" on public.automation_events;
create policy "automation_admin_select" on public.automation_events for select using (public.org_can_admin(organization_id));

drop policy if exists "automation_log_member_select" on public.automation_log;
drop policy if exists "automation_log_admin_write" on public.automation_log;
create policy "automation_log_member_select" on public.automation_log for select using (public.org_can_read(organization_id));
create policy "automation_log_admin_write" on public.automation_log for all using (public.org_can_admin(organization_id)) with check (public.org_can_admin(organization_id));


drop policy if exists "notifications_member_all" on public.internal_notifications;
create policy "notifications_member_all" on public.internal_notifications for all using (public.org_can_read(organization_id)) with check (public.org_can_write(organization_id));

drop policy if exists "audit_admin_select" on public.audit_log;
create policy "audit_admin_select" on public.audit_log for select using (public.org_can_admin(organization_id));

drop policy if exists "submissions_member_select" on public.public_submissions;
drop policy if exists "submissions_member_update" on public.public_submissions;
drop policy if exists "submissions_admin_delete" on public.public_submissions;
create policy "submissions_member_select" on public.public_submissions for select using (public.org_can_read(organization_id));
create policy "submissions_member_update" on public.public_submissions for update using (public.org_can_write(organization_id)) with check (public.org_can_write(organization_id));
create policy "submissions_admin_delete" on public.public_submissions for delete using (public.org_can_admin(organization_id));

drop trigger if exists public_submissions_set_updated_at on public.public_submissions;
create trigger public_submissions_set_updated_at before update on public.public_submissions for each row execute function public.set_updated_at();
drop trigger if exists public_submissions_audit on public.public_submissions;
create trigger public_submissions_audit after insert or update or delete on public.public_submissions for each row execute function public.audit_record_change();
drop trigger if exists public_submissions_queue_automation on public.public_submissions;
create trigger public_submissions_queue_automation after insert or update on public.public_submissions for each row execute function public.queue_automation_event();

drop trigger if exists automation_log_set_updated_at on public.automation_log;
create trigger automation_log_set_updated_at before update on public.automation_log for each row execute function public.set_updated_at();

create index if not exists public_submissions_org_created_idx on public.public_submissions(organization_id, created_at desc);
create index if not exists automation_events_status_idx on public.automation_events(status, created_at);
create index if not exists automation_log_org_created_idx on public.automation_log(organization_id, created_at desc);
create index if not exists audit_log_org_created_idx on public.audit_log(organization_id, created_at desc);
create index if not exists public_submission_limits_idx on public.public_submission_limits(organization_id, client_token, submitted_at desc);


create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  tax_code text,
  notes text,
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.customers enable row level security;

drop policy if exists "customers_member_select" on public.customers;
drop policy if exists "customers_member_insert" on public.customers;
drop policy if exists "customers_member_update" on public.customers;
drop policy if exists "customers_admin_delete" on public.customers;
create policy "customers_member_select" on public.customers
for select using (public.org_can_read(organization_id));
create policy "customers_member_insert" on public.customers
for insert with check (public.org_can_write(organization_id));
create policy "customers_member_update" on public.customers
for update using (public.org_can_write(organization_id)) with check (public.org_can_write(organization_id));
create policy "customers_admin_delete" on public.customers
for delete using (public.org_can_admin(organization_id));

drop trigger if exists customers_set_updated_at on public.customers;
create trigger customers_set_updated_at
before update on public.customers
for each row execute function public.set_updated_at();

drop trigger if exists customers_audit on public.customers;
create trigger customers_audit
after insert or update or delete on public.customers
for each row execute function public.audit_record_change();

create index if not exists customers_organization_idx on public.customers(organization_id);
create index if not exists customers_created_at_idx on public.customers(created_at desc);


create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  title text not null,
  status text,
  priority text,
  due_date date,
  assignee text,
  notes text,
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.tasks enable row level security;

drop policy if exists "tasks_member_select" on public.tasks;
drop policy if exists "tasks_member_insert" on public.tasks;
drop policy if exists "tasks_member_update" on public.tasks;
drop policy if exists "tasks_admin_delete" on public.tasks;
create policy "tasks_member_select" on public.tasks
for select using (public.org_can_read(organization_id));
create policy "tasks_member_insert" on public.tasks
for insert with check (public.org_can_write(organization_id));
create policy "tasks_member_update" on public.tasks
for update using (public.org_can_write(organization_id)) with check (public.org_can_write(organization_id));
create policy "tasks_admin_delete" on public.tasks
for delete using (public.org_can_admin(organization_id));

drop trigger if exists tasks_set_updated_at on public.tasks;
create trigger tasks_set_updated_at
before update on public.tasks
for each row execute function public.set_updated_at();

drop trigger if exists tasks_audit on public.tasks;
create trigger tasks_audit
after insert or update or delete on public.tasks
for each row execute function public.audit_record_change();

create index if not exists tasks_organization_idx on public.tasks(organization_id);
create index if not exists tasks_created_at_idx on public.tasks(created_at desc);
create index if not exists tasks_status_idx on public.tasks(organization_id, status);
create index if not exists tasks_due_date_idx on public.tasks(organization_id, due_date);


create table if not exists public.quotes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  number text not null,
  customer_name text not null,
  issue_date date,
  valid_until date,
  status text,
  total numeric(12,2),
  notes text,
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.quotes enable row level security;

drop policy if exists "quotes_member_select" on public.quotes;
drop policy if exists "quotes_member_insert" on public.quotes;
drop policy if exists "quotes_member_update" on public.quotes;
drop policy if exists "quotes_admin_delete" on public.quotes;
create policy "quotes_member_select" on public.quotes
for select using (public.org_can_read(organization_id));
create policy "quotes_member_insert" on public.quotes
for insert with check (public.org_can_write(organization_id));
create policy "quotes_member_update" on public.quotes
for update using (public.org_can_write(organization_id)) with check (public.org_can_write(organization_id));
create policy "quotes_admin_delete" on public.quotes
for delete using (public.org_can_admin(organization_id));

drop trigger if exists quotes_set_updated_at on public.quotes;
create trigger quotes_set_updated_at
before update on public.quotes
for each row execute function public.set_updated_at();

drop trigger if exists quotes_audit on public.quotes;
create trigger quotes_audit
after insert or update or delete on public.quotes
for each row execute function public.audit_record_change();

create index if not exists quotes_organization_idx on public.quotes(organization_id);
create index if not exists quotes_created_at_idx on public.quotes(created_at desc);
create index if not exists quotes_status_idx on public.quotes(organization_id, status);
create index if not exists quotes_issue_date_idx on public.quotes(organization_id, issue_date);


create table if not exists public.quote_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  quote_number text not null,
  description text not null,
  quantity numeric not null,
  unit_price numeric(12,2) not null,
  total numeric(12,2),
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.quote_items enable row level security;

drop policy if exists "quote_items_member_select" on public.quote_items;
drop policy if exists "quote_items_member_insert" on public.quote_items;
drop policy if exists "quote_items_member_update" on public.quote_items;
drop policy if exists "quote_items_admin_delete" on public.quote_items;
create policy "quote_items_member_select" on public.quote_items
for select using (public.org_can_read(organization_id));
create policy "quote_items_member_insert" on public.quote_items
for insert with check (public.org_can_write(organization_id));
create policy "quote_items_member_update" on public.quote_items
for update using (public.org_can_write(organization_id)) with check (public.org_can_write(organization_id));
create policy "quote_items_admin_delete" on public.quote_items
for delete using (public.org_can_admin(organization_id));

drop trigger if exists quote_items_set_updated_at on public.quote_items;
create trigger quote_items_set_updated_at
before update on public.quote_items
for each row execute function public.set_updated_at();

drop trigger if exists quote_items_audit on public.quote_items;
create trigger quote_items_audit
after insert or update or delete on public.quote_items
for each row execute function public.audit_record_change();

create index if not exists quote_items_organization_idx on public.quote_items(organization_id);
create index if not exists quote_items_created_at_idx on public.quote_items(created_at desc);


create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  customer_name text,
  payment_date date,
  amount numeric(12,2) not null,
  method text,
  status text,
  reference text,
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.payments enable row level security;

drop policy if exists "payments_member_select" on public.payments;
drop policy if exists "payments_member_insert" on public.payments;
drop policy if exists "payments_member_update" on public.payments;
drop policy if exists "payments_admin_delete" on public.payments;
create policy "payments_member_select" on public.payments
for select using (public.org_can_read(organization_id));
create policy "payments_member_insert" on public.payments
for insert with check (public.org_can_write(organization_id));
create policy "payments_member_update" on public.payments
for update using (public.org_can_write(organization_id)) with check (public.org_can_write(organization_id));
create policy "payments_admin_delete" on public.payments
for delete using (public.org_can_admin(organization_id));

drop trigger if exists payments_set_updated_at on public.payments;
create trigger payments_set_updated_at
before update on public.payments
for each row execute function public.set_updated_at();

drop trigger if exists payments_audit on public.payments;
create trigger payments_audit
after insert or update or delete on public.payments
for each row execute function public.audit_record_change();

create index if not exists payments_organization_idx on public.payments(organization_id);
create index if not exists payments_created_at_idx on public.payments(created_at desc);
create index if not exists payments_status_idx on public.payments(organization_id, status);
create index if not exists payments_payment_date_idx on public.payments(organization_id, payment_date);


create table if not exists public.ai_requests (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  request_type text,
  input_text text,
  output_text text,
  status text,
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.ai_requests enable row level security;

drop policy if exists "ai_requests_member_select" on public.ai_requests;
drop policy if exists "ai_requests_member_insert" on public.ai_requests;
drop policy if exists "ai_requests_member_update" on public.ai_requests;
drop policy if exists "ai_requests_admin_delete" on public.ai_requests;
create policy "ai_requests_member_select" on public.ai_requests
for select using (public.org_can_read(organization_id));
create policy "ai_requests_member_insert" on public.ai_requests
for insert with check (public.org_can_write(organization_id));
create policy "ai_requests_member_update" on public.ai_requests
for update using (public.org_can_write(organization_id)) with check (public.org_can_write(organization_id));
create policy "ai_requests_admin_delete" on public.ai_requests
for delete using (public.org_can_admin(organization_id));

drop trigger if exists ai_requests_set_updated_at on public.ai_requests;
create trigger ai_requests_set_updated_at
before update on public.ai_requests
for each row execute function public.set_updated_at();

drop trigger if exists ai_requests_audit on public.ai_requests;
create trigger ai_requests_audit
after insert or update or delete on public.ai_requests
for each row execute function public.audit_record_change();

create index if not exists ai_requests_organization_idx on public.ai_requests(organization_id);
create index if not exists ai_requests_created_at_idx on public.ai_requests(created_at desc);
create index if not exists ai_requests_status_idx on public.ai_requests(organization_id, status);


drop trigger if exists customers_queue_automation on public.customers;
create trigger customers_queue_automation
after insert or update on public.customers
for each row execute function public.queue_automation_event();

drop trigger if exists tasks_queue_automation on public.tasks;
create trigger tasks_queue_automation
after insert or update on public.tasks
for each row execute function public.queue_automation_event();

drop trigger if exists quotes_queue_automation on public.quotes;
create trigger quotes_queue_automation
after insert or update on public.quotes
for each row execute function public.queue_automation_event();

drop trigger if exists quote_items_queue_automation on public.quote_items;
create trigger quote_items_queue_automation
after insert or update on public.quote_items
for each row execute function public.queue_automation_event();

drop trigger if exists payments_queue_automation on public.payments;
create trigger payments_queue_automation
after insert or update on public.payments
for each row execute function public.queue_automation_event();

drop trigger if exists ai_requests_queue_automation on public.ai_requests;
create trigger ai_requests_queue_automation
after insert or update on public.ai_requests
for each row execute function public.queue_automation_event();



insert into storage.buckets (id, name, public)
values ('easycome-documents', 'easycome-documents', false)
on conflict (id) do nothing;

drop policy if exists "easycome_documents_member_select" on storage.objects;
drop policy if exists "easycome_documents_member_insert" on storage.objects;
drop policy if exists "easycome_documents_member_update" on storage.objects;
drop policy if exists "easycome_documents_admin_delete" on storage.objects;
create policy "easycome_documents_member_select" on storage.objects for select
using (bucket_id = 'easycome-documents' and public.org_can_read((storage.foldername(name))[1]::uuid));
create policy "easycome_documents_member_insert" on storage.objects for insert
with check (bucket_id = 'easycome-documents' and public.org_can_write((storage.foldername(name))[1]::uuid));
create policy "easycome_documents_member_update" on storage.objects for update
using (bucket_id = 'easycome-documents' and public.org_can_write((storage.foldername(name))[1]::uuid));
create policy "easycome_documents_admin_delete" on storage.objects for delete
using (bucket_id = 'easycome-documents' and public.org_can_admin((storage.foldername(name))[1]::uuid));

-- Primo accesso sicuro:
-- 1) registrati con titolare51@example.com;
-- 2) l'app chiama claim_owner_by_email e assegna il ruolo owner solo a quell'indirizzo;
-- 3) gli altri utenti vengono aggiunti dal titolare in organization_members.
