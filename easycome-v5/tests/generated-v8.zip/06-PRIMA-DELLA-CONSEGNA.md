# Prima della consegna al cliente

## 1. Accesso e sicurezza
- [ ] Eseguito supabase/schema.sql senza errori.
- [ ] Registrato il titolare con titolare51@example.com.
- [ ] Verificato che il titolare riceva il ruolo owner.
- [ ] Creato almeno un utente viewer e verificati i permessi di sola lettura.
- [ ] Verificata la cancellazione soltanto con owner/admin.

## 2. Flussi operativi
- [ ] Creato, modificato, duplicato ed eliminato un record per ogni sezione.
- [ ] Provate tabella, foglio Excel, bacheca, agenda, calendario, disponibilità e schede disponibili.
- [ ] Esportato e reimportato un CSV.
- [ ] Creato un backup JSON e verificato il contenuto.
- [ ] Inviata una richiesta di prova da Easy Come Hub.
- [ ] Verificati i controlli anti-sovrapposizione quando presenti.

## 3. Automazioni
- Nessuna automazione personalizzata da testare.

## 4. Consegna
- [ ] Rimossi o sostituiti i dati dimostrativi.
- [ ] Configurati dominio, Site URL e Redirect URLs.
- [ ] Consegnata la guida al cliente.
- [ ] Concordata la durata del supporto iniziale (30 giorni).
- [ ] Consegnato un backup iniziale.
