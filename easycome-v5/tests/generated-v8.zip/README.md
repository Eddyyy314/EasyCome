# Impresa Test 51

Pacchetto generato con **Easy Come Studio V8** e bloccato da un controllo qualità prima del download.

## Contenuto

- gestionale dinamico con 7 sezioni;
- viste tabella, foglio Excel, bacheca, agenda, calendario, disponibilità e schede quando coerenti;
- import/export CSV e backup JSON;
- audit log, permessi reali e Storage documenti privato;
- modalità demo locale immediata;
- collegamento Supabase per login e dati cloud;
- schema SQL con Row Level Security;
- Easy Come Hub ridisegnato per manuale, assistenza, incontri, nuove funzioni e gestione tecnica;
- motore prezzi dinamici predisposto;
- 0 automazioni configurate;
- Edge Function per email, webhook, notifiche, task e aggiornamenti;
- file Vercel e Netlify per il deploy;
- workbook Excel, manuale PDF, executive summary e brand kit;
- sito pubblico e PWA mobile quando selezionati;
- workflow n8n e piano Make quando sono presenti automazioni;
- endpoint AI configurabile quando viene selezionato il modulo AI;
- accesso al profilo Easy Come per ordini, download, incontri, assistenza e gestione dell’eventuale abbonamento tecnico.

## Moduli

- Clienti e CRM
- Attività e scadenze
- Preventivi
- Registro pagamenti e caparre
- Report e KPI
- Motore automazioni
- Utenti, ruoli e permessi
- Sito pubblico coordinato
- App PWA installabile
- Brand kit completo
- AI tramite integrazione
- Manuale & Easy Come Hub

## Avvio immediato in demo

Apri il file index.html con un server statico. Da Terminale:

```bash
npx serve .
```

Poi apri l'indirizzo mostrato. Senza Supabase il gestionale funziona in modalità locale usando il browser.

## Collegamento Supabase

1. Crea un progetto Supabase.
2. Apri **SQL Editor** ed esegui supabase/schema.sql.
3. Apri js/config.js.
4. Sostituisci INSERISCI_PROJECT_URL con il Project URL.
5. Sostituisci INSERISCI_PUBLISHABLE_KEY con la publishable/anon key.
6. Apri il gestionale e registrati usando l’email titolare `titolare51@example.com`. Solo quell’indirizzo può reclamare il ruolo owner.
7. Pubblica le Edge Functions `process-automations` e `invite-member`.
8. In Supabase Auth configura Site URL e Redirect URLs con il dominio finale.

Non inserire mai la service role key nel frontend.

## Automazioni

Le automazioni sono in automations/automation-plan.json e nella Edge Function:

```text
supabase/functions/process-automations/index.ts
```

Per pubblicarla:

```bash
supabase functions deploy process-automations --no-verify-jwt
supabase functions deploy invite-member
```

Secret opzionali:

- AUTOMATION_CRON_SECRET
- RESEND_API_KEY
- EMAIL_FROM
- AI_API_URL
- AI_API_KEY
- AI_MODEL

Programma una chiamata periodica alla funzione per processare la coda.

## Profilo e continuità Easy Come

Accedi all’indirizzo https://easy-come.it/profilo.html con lo stesso account usato per l’acquisto. Da lì puoi riscaricare il pacchetto, chiedere assistenza, prenotare un incontro e gestire il servizio tecnico mensile quando attivo.

## Prezzo Easy Come configurato

- Pacchetto base: €99.00
- Totale da pagare ora: €163.80
- Gestione tecnica continuativa: €30/mese (opzionale, gestibile dal profilo)
- Implementazione assistita: non selezionata
- Moduli e personalizzazioni: €64.80
- **Totale da pagare ora: €163.80**

## Limite importante

Il pacchetto contiene codice, database e configurazione. Email, WhatsApp, checkout online e AI richiedono le rispettive API. Il modulo “Fatture e scadenze” è una gestione interna e non sostituisce un servizio di fatturazione elettronica o un software contabile certificato.
