# Checklist collaudo

- [ ] Login con le stesse credenziali Easy Come
- [ ] Recupero password verificato
- [ ] Creazione, modifica ed eliminazione record
- [ ] Ricerca in ogni sezione
- [ ] Permessi utenti verificati
- [ ] Visualizzazione mobile
- [ ] Backup ed esportazione dati
- [ ] Easy Come Hub aperto con lo stesso account
- [ ] Richiesta di assistenza inviata dal Hub
- [ ] Manuale personalizzato verificato


Sezioni da verificare: Clienti, Attività, Preventivi, Righe preventivo, Pagamenti, Registro automazioni, Attività AI.
